﻿using CallAll;
using Microsoft.Extensions.DependencyInjection;
using Telegram.Bot;



class Program
{
    public static async Task Main(string[] args)
    {
        var services = new ServiceCollection();
        services.AddSingleton<ITelegramBotClient>(new TelegramBotClient("8583175698:AAHgUVaRGkg_WN-qZ9YqTSTmAWvSTKzKSEY"));
        services.AddTransient<RunBot>();

        var provider = services.BuildServiceProvider(); 
        var runBot = provider.GetRequiredService<RunBot>();
        await runBot.RunAsync();



    }
}